default_app_config = 'django_simple_bulk_emailer.apps.Config'
